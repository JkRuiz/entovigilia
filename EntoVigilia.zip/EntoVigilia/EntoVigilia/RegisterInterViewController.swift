//
//  RegisterInterViewController.swift
//  EntoVigilia
//
//  Created by Juan Camilo Ruiz on 3/18/19.
//  Copyright © 2019 Juan Camilo Ruiz. All rights reserved.
//

import UIKit

class RegisterInterViewController: UIViewController {

    var registers: [RegisterInter] = []
    
    @IBOutlet weak var cocinaImage: UIImageView!
    @IBOutlet weak var cocinaRastrosField: UITextField!
    @IBOutlet weak var cocinaHuevosField: UITextField!
    @IBOutlet weak var cocinaLarvasField: UITextField!
    @IBOutlet weak var cocinaNinfasField: UITextField!
    @IBOutlet weak var cocinaAdultosField: UITextField!
    @IBOutlet weak var dormitorioImage: UIImageView!
    @IBOutlet weak var dormitorioRastrosFields: UITextField!
    @IBOutlet weak var dormitorioHuevosField: UITextField!
    @IBOutlet weak var dormitorioLarvasField: UITextField!
    @IBOutlet weak var dormitorioNinfasField: UITextField!
    @IBOutlet weak var dormitorioAdultosField: UITextField!
    @IBOutlet weak var zonaSocialImage: UIImageView!
    @IBOutlet weak var zonaSocialRastrosField: UITextField!
    @IBOutlet weak var zonaSocialHuevosField: UITextField!
    @IBOutlet weak var zonaSocialLarvasField: UITextField!
    @IBOutlet weak var zonaSocialNinfasField: UITextField!
    @IBOutlet weak var zonaSocialAdultosField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
