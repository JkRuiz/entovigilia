//
//  RegisterViewController.swift
//  EntoVigilia
//
//  Created by Juan Camilo Ruiz on 3/15/19.
//  Copyright © 2019 Juan Camilo Ruiz. All rights reserved.
//

import UIKit
import os.log

class RegisterPeroViewController: UIViewController{

    var registers: [RegisterPero] = []
    
    @IBOutlet weak var gallineroImage: UIImageView!
    @IBOutlet weak var gallineroRastrosField: UITextField!
    @IBOutlet weak var gallineroHuevosField: UITextField!
    @IBOutlet weak var gallineroLarvasField: UITextField!
    @IBOutlet weak var gallineroNinfasField: UITextField!
    @IBOutlet weak var gallineroAdultosField: UITextField!
    @IBOutlet weak var corralImage: UIImageView!
    @IBOutlet weak var corralRastrosField: UITextField!
    @IBOutlet weak var corralHuevosField: UITextField!
    @IBOutlet weak var corralLarvasField: UITextField!
    @IBOutlet weak var corralNinfasField: UITextField!
    @IBOutlet weak var corralAdultosField: UITextField!
    @IBOutlet weak var depositoImage: UIImageView!
    @IBOutlet weak var depositoRastrosField: UITextField!
    @IBOutlet weak var depositoHuevosField: UITextField!
    @IBOutlet weak var depositoLarvasField: UITextField!
    @IBOutlet weak var depositoNinfasField: UITextField!
    @IBOutlet weak var depositoAdultosField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        /*
        gallineroAdultosField!.delegate = self
        gallineroNinfasField!.delegate = self
        gallineroLarvasField!.delegate = self
        gallineroHuevosField!.delegate = self
        gallineroRastrosField!.delegate = self
        corralAdultosField!.delegate = self
        corralNinfasField!.delegate = self
        corralLarvasField!.delegate = self
        corralHuevosField!.delegate = self
        corralRastrosField!.delegate = self
        depositoAdultosField!.delegate = self
        depositoNinfasField!.delegate = self
        depositoLarvasField!.delegate = self
        depositoHuevosField!.delegate = self
        depositoRastrosField!.delegate = self
 */
    }
    
    
    @IBAction func saveRegister(_ sender: UIBarButtonItem) {
        var reg : RegisterPero
        reg = RegisterPero (rastroGallineroValue: gallineroRastrosField.text!, huevosGallineroValue:gallineroHuevosField.text!, larvasGallineroValue: gallineroLarvasField.text!, ninfasGallineroValue: gallineroNinfasField.text!, adultosGallineroValue:gallineroAdultosField.text!, rastroCorralValue:corralRastrosField.text!, huevosCorralValue:corralHuevosField.text!, larvasCorralValue:corralLarvasField.text!, ninfasCorralValue: corralNinfasField.text!, adultosCorralValue:corralAdultosField.text!, rastroDepositoValue: depositoRastrosField.text!, huevosDepositoValue:depositoHuevosField.text!, larvasDepositoValue:depositoLarvasField.text!, ninfasDepositoValue: depositoNinfasField.text!, adultosDepositoValue:depositoAdultosField.text!)
        
        registers.append(reg)
        
    }
    
    
}

