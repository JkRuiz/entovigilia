//
//  RegisterTableViewCell.swift
//  EntoVigilia
//
//  Created by Juan Camilo Ruiz on 3/15/19.
//  Copyright © 2019 Juan Camilo Ruiz. All rights reserved.
//

import UIKit

class RegisterTableViewCell: UITableViewCell {

    //MARKER: Atributes
    @IBOutlet weak var GallineroImage: UIImageView!
    @IBOutlet weak var RastrosGallineroField: UITextField!
    @IBOutlet weak var HuevosGallineroField: UITextField!
    @IBOutlet weak var LarvasGallineroField: UITextField!
    @IBOutlet weak var NinfasGallineroField: UITextField!
    @IBOutlet weak var AdultosGallineroField: UITextField!
    @IBOutlet weak var RastrosGallineroLabel: UILabel!
    @IBOutlet weak var HuevosGallineroLabel: UILabel!
    @IBOutlet weak var LarvasGallineroLabel: UILabel!
    @IBOutlet weak var NinfasGallineroLabel: UILabel!
    @IBOutlet weak var AdultosGallineroLabel: UILabel!
    
    
}
